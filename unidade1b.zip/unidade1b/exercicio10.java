import java.io.*;

public class exercicio10 {

    public static void exercicoA() {
        i = 0;
        while (i < n) {
            i++;
            a--;
            b--;
            c--;
        }
        for (i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a--;
                b--;
            }
        }
    }

    public static void exercicoB() {
        i = 0;
        while (i < n) {
            i++;
            a--;
            b--;
            c--;
            d--;
            e--;
        }
        for (i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int z = 0; z < n; z++) {
                    a--;
                    b--;
                    c--;
                    d--;
                }
            }
        }
    }

    public static void exercicoC() {
        i = 0;
        while (i < n) {
            i++;
        }
        for (i = n; i < 0; i=/2) {

            }
        }

    }

    public static void exercicoD() {
        i = 0;
        i++;
        a--;
        b--;
        c--;
        d--;
        e--;
        for (i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int z = 0; z < n; z++) {
                    a--;
                    b--;
                }
            }
        }
    }

    public static void exercicoE() {
        i = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a--;
                b--;
                c--;
                d--;
                e--;
            }
        }
        for (i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int z = 0; z < n; z++) {
                    for (int k = 0; k < n; k++) {
                        a--;
                        b--;
                        c--;
                        d--;
                        e--;
                        f--;
                        g--;
                        h--;
                        j--;
                        k--;
                    }
                }
            }
        }
        i = 0;
        while (i < n / 2) {
            a--;
        }
    }

    public static void exercicoF() {
        for (i = n; i < 0; i=/2) {
            a--;
            }
            i=0;
            while (i<5) {
                for (i = n; i < 0; i=/2) {
                    a--;
                    }
                }
            }

    }

    public static void main(String[] args) {

    }

}