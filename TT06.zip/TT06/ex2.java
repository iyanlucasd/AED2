public class ex2 extends Geracao {


    public static void main(String[] args) {
        Insercao obj = new Insercao(10);
        obj.aleatorio();
        obj.mostrar();
        obj.sort();
        obj.mostrar();
    }
}
