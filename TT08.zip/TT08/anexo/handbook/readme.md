# Professor,
 Este é um arquivo que eu fiz para **estudar**! é um resumo deste capítulo, assim como fiz em somatórios. 

***NÃO FAZ PARTE DO TRABALHO***

*Abraços,*
*Iyan*
